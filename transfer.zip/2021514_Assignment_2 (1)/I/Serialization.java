package I;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
// import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

class test implements Serializable{
    int i = 10;
    int j = 20;
    transient String k = "Akash";
}
public class Serialization {
    public static void main(String[] args) throws IOException {
        ObjectInputStream i1 = null;
        ObjectOutputStream O = null;
        try{
            test t = new test();
            FileOutputStream f = new FileOutputStream("ting.txt");
            O = new ObjectOutputStream(f);
            O.writeObject(t);

            FileInputStream I = new FileInputStream("ting.txt");
            i1 = new ObjectInputStream(I);
            test out = (test) i1.readObject();
            System.out.println(out.i);
            System.out.println(out.j);
            System.out.println(out.k);
        }
        catch (ClassNotFoundException e1) {
            e1.printStackTrace();
        } 
        finally{
            if(i1!=null){
            i1.close();}
            if(O!=null){
            O.close();}
        }
    }
}
