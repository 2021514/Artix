package I;
// import java.io.FileInputStream;
// //import java.io.File;
// import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedReader;
// public class Main {
//     public static void main(String[] args) {
//         File file = new File("RR.txt");
//         try {
import java.io.BufferedWriter;

//             // trying to create a file based on the object
//             boolean value = file.createNewFile();
//             if (value) {
//               System.out.println("The new file is created.");
//             }
//             else {
//               System.out.println("The file already exists.");
//             }
//           }
//           catch(Exception e) {
//             e.getStackTrace();
//           }
//         }
// }
// public class Main {
//     public static void main(String[] args) {
//         //String s = "I am learning java";
//         try {
//             FileInputStream file = new FileInputStream("try.txt");
//             System.out.println("Available bytes: "+ file.available());
//             int i = file.read();
//             while(i!=-1){
//                 System.out.print((char)i);
//                 i = file.read();
//             }
//             file.close();
//           }
//           catch(Exception e) {
//             e.getStackTrace();
//           }
//     }
// }


// public class Main {
//     public static void main(String[] args) {
//         String s = "I am learning java";
//         try {
//             FileOutputStream file = new FileOutputStream("try.txt");
//             byte[] array = s.getBytes();
//             file.write(array);

//             file.close();
//           }
//           catch(Exception e) {
//             e.getStackTrace();
//           }
//     }
// }
public class Main{
    public static void main(String[] args) {
        try{
            char[] n = new char[50];
            FileReader file = new FileReader("ting.txt");
            //System.out.println(file.Available());
            BufferedReader file1 = new BufferedReader(file);
           
            FileWriter x = new FileWriter("try.txt");
            BufferedWriter file2 = new BufferedWriter(x);
            //byte[] array = new byte[100];
            file1.read(n);
            file2.write(n);
            file.close();
            file2.close();
        }
        catch(Exception e){
            e.getMessage();
        }
    }
}