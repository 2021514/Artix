package I;
//import java.lang.Thread
// class thread1 extends Thread{
//     //@Override
//     public void Run(){
//         int i=0;
//         while(i<40000){
//             System.out.println("Akash");
//             i++;
//         }
//     }
// }
// class thread2 extends Thread{
//     //@Override
//     public void Run(){
//         int i=0;
//         while(i<40000){
//             System.out.println("Kushwaha");
//             i++;
//         }
//     }
// }
// public class Thread {
//     public static void main(String[] args) {
//         thread1 t1 = new thread1();
//         thread2 t2 = new thread2();
//         t1.Run();
//         t2.Run();
//     }
// }

class runnable1 implements Runnable{
    @Override
    public void run(){
        int i=0;
        while(i<40000){
            System.out.println("Akash");
            i++;
        }
    }
}
class runnable2 implements Runnable{
    @Override
    public void run(){
        int i=0;
        while(i<40000){
            System.out.println("Kushwaha");
            i++;
        }
    }
}
public class Thread{
    public static void main(String[] args) {
        runnable1 r = new runnable1();
        Thread t1 = new Thread(r);
        runnable2 r1 = new runnable2();
        Thread t2 = new Thread(r1);
        //t1.run();

    }
}