package I;
import java.io.*;

// public class O {
//   public static void main(String args[]) {

//     byte[] array = new byte[100];

//     try {
//       InputStream input = new FileInputStream("input.txt");

//       System.out.println("Available bytes in the file: " + input.available());

//       // Read byte from the input stream
//       input.read(array);
//       System.out.println("Data read from the file: ");

//       // Convert byte array into string
//       String data = new String(array);
//       System.out.println(data);

//       // Close the input stream
//       input.close();
//     } catch (Exception e) {
//       e.getStackTrace();
//     }
//   }
// }

class Manager implements Serializable{
    String name;
    public Manager(String s){
        this.name = s;
    }
}
public class O {
    public static void Serializable() throws IOException {
  
      Manager s1 = new Manager("Army");
      ObjectOutputStream out = null;
      try{
        out = new ObjectOutputStream(new FileOutputStream("ting.txt"));
        out.writeObject(s1);
      }
      finally{
        out.close();
      }
    }
    public static void deserialize()
        throws IOException, ClassNotFoundException {
        ObjectInputStream in = null;
        try {
            in = new ObjectInputStream (
            new FileInputStream("try.txt"));
            Manager s1 = (Manager) in.readObject();
            System.out.println(s1.name);
        } finally {
            if(in!=null)
            in.close();
        }
    }
    public static void main(String[] args) throws IOException,ClassNotFoundException {
        Serializable();
        deserialize();
    }
}
  
